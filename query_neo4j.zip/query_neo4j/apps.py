from django.apps import AppConfig


class Neo4JQueryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'query_neo4j'
